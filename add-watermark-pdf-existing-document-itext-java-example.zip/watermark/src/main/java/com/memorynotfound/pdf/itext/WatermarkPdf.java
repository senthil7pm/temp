package com.memorynotfound.pdf.itext;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;

public class WatermarkPdf {

    public static void main(String... args) throws IOException, DocumentException {

        // read existing pdf
        PdfReader reader = new PdfReader(getResource("/example.pdf"));
        PdfStamper stamper = new PdfStamper(reader, new FileOutputStream("watermarked-existing-pdf.pdf"));

        // text watermark
        Font FONT = new Font(Font.FontFamily.HELVETICA, 34, Font.BOLD, new GrayColor(0.5f));
        Phrase p = new Phrase("Memorynotfound (watermark)", FONT);

        // image watermark
        Image img = Image.getInstance(getResource("/memorynotfound-logo.jpg"));
        float w = img.getScaledWidth();
        float h = img.getScaledHeight();

        // properties
        PdfContentByte over;
        Rectangle pagesize;
        float x, y;

        // loop over every page
        int n = reader.getNumberOfPages();
        for (int i = 1; i <= n; i++) {

            // get page size and position
            pagesize = reader.getPageSizeWithRotation(i);
            x = (pagesize.getLeft() + pagesize.getRight()) / 2;
            y = (pagesize.getTop() + pagesize.getBottom()) / 2;
            over = stamper.getOverContent(i);
            over.saveState();

            // set transparency
            PdfGState state = new PdfGState();
            state.setFillOpacity(0.2f);
            over.setGState(state);

            // add watermark text and image
            if (i % 2 == 1) {
                ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p, x, y, 0);
            } else {
                over.addImage(img, w, 0, 0, h, x - (w / 2), y - (h / 2));
            }

            over.restoreState();
        }
        stamper.close();
        reader.close();
    }

    private static URL getResource(String name){
        return WatermarkPdf.class.getResource(name);
    }
}
